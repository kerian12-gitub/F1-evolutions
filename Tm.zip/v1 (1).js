let img = document.getElementById("f11980");

let info = document.getElementById("info");

let coord = document.getElementById("coord");

img.addEventListener("mousemove", function (e) {
  let x = e.offsetX;
  let y = e.offsetY;
    

  if (x > 51 && x<105 && y > 168 && y < 210||x > 137 && x<174 && y > 144 && y < 154 ||x > 365 && x<407 && y >151 && y < 179 ||x > 293 && x<336 && y > 172 && y < 217) {
    info.innerHTML = "Les Pneus: En 1983, le fabricant Goodyear introduit les premiers pneus pluie réalisés à partir de la technologie radiale. Le pneu radial est composé d’une structure en fils d’acier qui améliore l’adhérence sur un sol mouillé et la tenue de route. En 1985, les couvertures chauffantes sont autorisées pour chauffer la gomme, car avec une température entre 70 et 90 degrés, l'adhérence s'améliore et les performances sont meilleures.";
  } else if (x > 237 && x<315 && y > 143 && y < 166) {
    info.innerHTML = "Le Volant: A cette période, le volant conserve sa forme ronde, mais il y a plus de choses dessus. Le système d’attache rapide permet au pilote de sortir plus rapidement de la voiture. Il y a aussi un bouton qui permet de déclencher le boost du turbo. Enfin, c’est le début de la communication entre le pilote et son écurie, grâce à un bouton «push to talk» sur le volant.";
  } else if (x > 51 && x<132 && y > 120 && y < 157 ||x > 360 && x<459 && y > 191 && y < 215 ) {
    info.innerHTML = "L'Aérodynamique: En 1980, l’écurie lotus tente de se débarrasser des ailerons et d’améliorer l’effet de sol. Néanmoins, la voiture rebondit. Lotus décide de créer la technologie des suspensions actives. Ces suspensions conservent une hauteur optimale par rapport aux ondulations du circuit. Les suspensions apportent un grand avantage, les autres écuries vont aussi en installer sur leurs voitures.";
  } else if (x > 227 && x<286 && y > 170 && y < 204 ) {
    info.innerHTML = "La Sécurité: Les châssis ont besoin d’être plus rigide, pour que l’effet de sol puisse fonctionner. En 1981, les monoplaces Mclaren possèdent un châssis en carbone. La plupart des gens sont sceptiques quant à la résistance de ce matériel. Mais lors d’un crash à 240 KM/H à Monza, le pilote sort indemne de sa voiture en carbone. Cet événement prouvera la résistance de ce matériel. Suite à ce crash, ce modèle de châssis sera la norme. Il s’agit d'un des plus grands progrès en termes de sécurité.";
  }
  else if (x > 137 && x<221 && y > 153 && y < 209) {
    info.innerHTML = "Le Moteur: Les écuries sont désormais toutes équipées de moteurs turbos. Pendant les années 80, la puissance des moteurs passe de 475 chevaux à 950 chevaux. Le moteur BMW 4 cylindres en ligne atteignait même les 1450 cv. Mais en 1988, la FIA décide de limiter la pression des turbos à 4 bars avant d’interdire les turbos en 1989, car ces moteurs étaient jugés trop puissants et trop dangereux.";
  }

})
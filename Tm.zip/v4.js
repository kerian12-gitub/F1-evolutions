let img = document.getElementById("f12000");

let info = document.getElementById("info");

let coord = document.getElementById("coord");

img.addEventListener("mousemove", function (e) {
  let x = e.offsetX;
  let y = e.offsetY;
    

  if (x > 32 && x<86 && y > 87 && y < 148||x > 257 && x<307 && y > 100 && y < 160 ||x > 393 && x<424 && y > 88 && y < 108) {
    info.innerHTML = "Les Pneus: Après plusieurs années avec des pneus rainurés, l’année 2008 marque un tournant. Lors des dépassements, des turbulences étaient créées par l’aileron arrière et le diffuseur, ce qui empêchait les adversaires de pouvoir dépasser. Afin de remédier à ce problème, il a été décidé que les pneus lisses (slicks) fassent leur retour. Ainsi, la voiture était fixée au sol par ces pneus.";
  }  else if (x > 55&& x<158 && y > 46 && y < 70 ||x > 318 && x<459 && y > 120 && y < 159 ) {
    info.innerHTML = "L'Aérodynamique: Durant ces années-là, les voitures subissaient des turbulences. L’aileron arrière et le diffuseur, pièce qui permet de plaquer la voiture au sol par un effet complexe, possèdent un placement qui crée des turbulences. C’est pourquoi en 2009, l’aileron arrière est placé plus haut et la largeur du diffuseur est diminuée. L’aileron avant, de type chasse-neige, permet de coller la voiture au sol. Sur celui-ci, des volets ajustables sont installés pour régler l’écoulement de l’air. Tous ces développements aérodynamiques sont permis grâce aux souffleries qui se développent avec la technologie de la mécanique des fluides numérique.";
  } else if (x > 218 && x<270 && y > 67 && y < 89 ) {
    info.innerHTML = "Le Volant: Désormais le volant possède une forme rectangulaire pour apporter un atout au niveau de l’aérodynamique. Toutes les écuries ont adopté un petit affichage qui permet de montrer les passages de vitesse avec de la lumière, les indications de sécurité, le rapport enclenché et le temps au tour. Il y a en plus énormément de boutons pour régler différentes choses, des molettes pour ajuster la pression des freins ou l’équilibrage entre le frein arrière et avant. Les palettes sont indispensables, certains pilotes en ont 6. Chaque écurie dispose d’un volant différent adapté à leurs besoins.";
  }
  else if (x > 118 && x<210 && y > 44 && y < 131) {
    info.innerHTML = "Le Moteur: En 2001, le moteur obligatoire est le V10 de 3000 centimètres cubes. Ferrari réussit à atteindre les 920 chevaux avec son moteur v10. La FIA, pour réduire l’impact sur la planète, décide en 2006 de réduire la cylindrée à 8 cylindres. En 2009, un système de récupération d’énergie est mis en place. Ce système, aussi nommé SREC, permet de récupérer la chaleur des freins, donc l’énergie cinétique pour créer une puissance supplémentaire de 80 chevaux pendant quelques secondes.";
  }
  else if (x > 201 && x<250 && y > 103 && y < 147) {
    info.innerHTML = "La Sécurité: Les roues sont désormais attachées à la voiture, car une roue peut peser jusqu’à 11.5 kg et peut être éjectée à une très grande vitesse, ce qui peut causer d'importants dégâts. Des coussins de protection, sur les côtés du cockpit, sont obligatoires en cas de choc latéral. De plus, les crash-tests renforcent la sécurité, car avec le développement des ordinateurs, les chocs peuvent être analysés en détail.";
  }
})
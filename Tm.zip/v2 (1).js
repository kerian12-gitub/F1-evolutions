let img = document.getElementById("f11970");

let info = document.getElementById("info");

let coord = document.getElementById("coord");

img.addEventListener("mousemove", function (e) {
  let x = e.offsetX;
  let y = e.offsetY;
   

  if (x > 70 && x<120 && y > 141 && y < 188 || x > 91 && x<129 && y > 114 && y < 126 || x > 355 && x<392 && y > 124 && y < 138 || x > 354 && x<396 && y > 148 && y < 185) {
    info.innerHTML = "Les Pneus: Avant 1971, les pneus sont semi-slicks, c’est-à-dire qu’ils possèdent trois rainures sur le bord droit et le reste est complètement lisse. Ainsi, le pneu évacue l’eau et possède une surface suffisamment grande pour conserver un bon appui. Un jour, un certain Mario Andretti, teste des pneus pas finis sans rainures. Il réalise alors que ces pneus complètement lisses sont plus performants et ils sont ajoutés en course.";
  } else if (x > 244 && x<345 && y > 135 && y < 180) {
    info.innerHTML = "La Sécurité: À cause des incendies causés par les réservoirs d’essence des voitures, les pilotes préfèrent ne pas être attachés afin de sortir plus rapidement. Néanmoins, après de nombreux accidents, les harnais sont devenus obligatoires. Les améliorations de l’aérodynamique augmentent les charges que les pilotes subissent. Le harnais est fixé à la voiture grâce à six points. De plus, pour éviter les incendies, la matière des réservoirs est améliorée. Pour empêcher les fuites de carburant lors d’accident, les tuyaux reliant le réservoir se referment automatiquement pour isoler le réservoir.";
  } else if (x > 254 && x<330 && y > 100 && y < 125) {
    info.innerHTML = "Le Volant: Il est fait de métal et est entouré de cuir. A cette époque, le volant sert juste à tourner les roues avant, car il est directement vissé sur la colonne de direction. En 1974, sa taille est réduite et un bouton est ajouté. Ce bouton sert à couper le moteur lors d’accident. En 1978, le volant peut se retirer rapidement grâce à un mécanisme de clip.";
  } else if (x > 23 && x<85 && y > 98 && y < 135 || x > 417 && x<452 && y > 153 && y < 181) {
    info.innerHTML = "L'Aérodynamique: Au début de la période, les voitures possèdent des ailerons placés en hauteur. Ils ne favorisent que légèrement l’appui aérodynamique. En 1977, l’écurie Lotus introduit l’effet de sol en formule 1. C’est un moyen de générer un important appui, grâce à un mécanisme de succion aérodynamique. Les voitures sont désormais plaquées au sol.";
  }
  else if (x > 140 && x<240 && y > 120 && y < 179) {
    info.innerHTML = "Le Moteur: Après des années avec le Ford Cosworth de 475 chevaux,en 1977, Renault propose un moteur 6 cylindres en forme de v de 1,5 L possédant un turbo. Le turbo optimise la combustion du carburant et ajoute donc de la performance. Les débuts sont compliqués, car le moteur manque de fiabilité. L’ajout d'un deuxième turbo va régler le problème et un avantage se crée. ";
  }

})
let img = document.getElementById("f1190");

let info = document.getElementById("info");

let coord = document.getElementById("coord");

img.addEventListener("mousemove", function (e) {
  let x = e.offsetX;
  let y = e.offsetY;
   

  if (x > 29 && x<75 && y > 186 && y < 235||x > 109 && x<146 && y > 165 && y < 180 ||x > 298 && x<341 && y > 192 && y < 242 ||x > 374 && x<421 && y > 171 && y < 182 ||x > 400 && x<425 && y > 182 && y < 192) {
    info.innerHTML = "Les Pneus: Les améliorations technologiques de années 90, notamment au niveau des pneumatiques, du moteur ou de l’aérodynamique, font que les voitures sont beaucoup plus rapides. En 1998, la Fédération internationale de l'automobile impose, pour ralentir les voitures en réduisant l'adhérence, des pneus moins larges et rainurés de 3 rainures à l’avant et de 4 à l’arrière.";
  }  else if (x > 31 && x<104 && y > 143 && y < 183 ||x > 366 && x<474 && y > 207 && y < 237 ) {
    info.innerHTML = "L'Aérodynamique: En 1994, les suspensions actives, si efficaces, vont être supprimées en même temps que les autres aides aux pilotages comme l’antipatinage et l’ABS. La largeur de la monoplace diminue alors que le poids minimum augmente. "; 
  } 
    else if (x > 267 && x<294 && y > 175 && y < 196 ||x > 234 && x<253 && y > 157 && y < 178) {
      info.innerHTML = "Le Volant: A cette période, Ferrari développe, sur la Ferrari 640, un volant qui possède deux palettes pour changer les rapports. Ce système plus rapide, prévient des risques de surrégime en évitant les erreurs de sélection de vitesses et libère de l’espace dans le cockpit qui servait au levier de vitesse. En 1994, Mclaren ajoute une commande pour l’embrayage, la radio et 2 ans plus tard, Ferrari insère un écran qui montre le passage de rapport et le temps au tour. A la fin de la décennie, le volant passe d'une forme ronde à une forme plus ovale.";
    }
    
  else if (x > 115 && x<217 && y > 150&& y < 224) {
    info.innerHTML = "Le Moteur: Après l’interdiction des moteurs turbos, il ne reste plus que les moteurs classiques atmosphériques. Même si la FIA voulait réduire la puissance des moteurs en interdisant le turbo, certains moteurs vont atteindre les 800 chevaux. La FIA va tout de même réduire la taille de la cylindrée en 1994 pour réduire les risques d’accident liés à la puissance du moteur. Dans les années 90, la plupart des moteurs sont composés de 10 cylindres en forme de v aussi appelés v10 qui atteignent les 730 chevaux.";
  }
  else if (x > 208 && x<291 && y > 196&& y < 232) {
    info.innerHTML = "La Sécurité: Au début des années 90, les monoplaces doivent être équipées d’une cellule de survie. C’est un dispositif très résistant en carbone kevlar, qui entoure le pilote pour le protéger. La cellule subit plusieurs crash-test sous différents angles pour être homologuée. Ce dispositif est ajouté après les crash d’Ayrton Senna et de Roland Ratzenberger à Imola en 1994. De plus, la réduction de la taille des pneus permet un ralentissement de la monoplace afin de renforcer la sécurité.";
  }

})
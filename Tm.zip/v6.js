let img = document.getElementById("f12020");

let info = document.getElementById("info");

let coord = document.getElementById("coord");

img.addEventListener("mousemove", function (e) {
  let x = e.offsetX;
   let y = e.offsetY;
   

  if (x > 62&& x<104 && y > 138 && y < 180||x > 105 && x<124 && y > 95 && y < 105 ||x > 342 && x<382 && y > 100 && y < 116 ||x > 337 && x<378 && y > 145 && y < 187) {
    info.innerHTML = "Les Pneus:  Les pneus subissent une évolution en 2022. Ces derniers passent de 33 cm,  à 45 cm. Cette augmentation permet une meilleure précision et une meilleure stabilité dans les virages. L’augmentation de la taille apporte une amélioration de la rigidité du pneu et le pneu se déforme beaucoup moins dans les virages, surtout pour les pneumatiques arrières.";
  }  else if (x > 47 && x<94 && y > 80 && y < 127 ||x > 396 && x<435 && y > 125 && y < 187  ) {
    info.innerHTML = "L'Aérodynamique: Les principales évolutions se passent en 2022. Les voitures sont prévues pour créer un maximum d’effet de sol grâce à de nouveaux diffuseurs qui plaquent au sol les voitures. Ainsi, l’air peut s’évacuer à l’arrière avec une hauteur plus importante, ce qui permet à la voiture de derrière de conserver un appui sur son aileron avant. Cette innovation favorise les dépassements,car l’appui aérodynamique est désormais plus important."; 
  } else if (x > 230 && x<288 && y > 111 && y < 127 ) {
    info.innerHTML = "Le Volant: Le volant est maintenant un vrai ordinateur. Le pilote peut se déplacer dans les réglages grâce à un écran. Les boutons, comme celui pour activer le DRS, sont toujours présents. Il y a un bouton pour limiter la vitesse dans les stands, confirmer l’arrêt aux stands, mettre la voiture en neutre afin d’éviter de faire une mauvaise manipulation avec les palettes et un bouton pour parler avec les stands. Des molettes sont aussi présentes pour régler la puissance du moteur en entrée ou en sortie de virage ou pour équilibrer les freins avant et arrière.";
  }

  else if (x > 119 && x<222 && y > 97&& y < 155 ) {
    info.innerHTML = "Le Moteur: Le moteur ne subit pas de changements. Il s’agit toujours du moteur V6 de 1,6 L combiné à des technologies hybrides, qui récupèrent l’énergie cinétique et thermique lors du freinage. L’énergie créée se stocke dans la batterie, qui va alimenter un deuxième moteur. Le moteur à essence couplé au moteur électrique permet de développer une puissance importante de plus de 800 chevaux.";
  }
  else if (x > 237 && x<296 && y > 95&& y < 111||x > 220 && x<332 && y > 131 && y < 172) {
    info.innerHTML = "La Sécurité: Les anciennes innovations, au niveau de la sécurité, ont été améliorées. Le halo est toujours présent. Les voitures possèdent des extincteurs intégrés, qui s’actionnent grâce à un petit interrupteur. La cellule de survie en carbone kevlar, qui sert à protéger le pilote, permet aussi de protéger les réservoirs de carburant lors de chocs. La cellule de survie subit énormément de crash-tests afin de prévoir comme cette dernière réagirait.";
  }

})
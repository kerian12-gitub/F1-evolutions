let img = document.getElementById("f12010");

let info = document.getElementById("info");

let coord = document.getElementById("coord");

img.addEventListener("mousemove", function (e) {
  let x = e.offsetX;
  let y = e.offsetY;
    

  if (x > 38 && x<104 && y > 133 && y < 191||x > 300 && x<354 && y > 158 && y < 216 ||x > 179 && x<240 && y > 72 && y < 95 ||x > 422 && x<487 && y > 99 && y < 186) {
    info.innerHTML = "Les Pneus: En 2011, Pirelli devient le seul fournisseur de pneus en F1. Il impose aux écuries deux types de pneumatiques: un pneumatique lisse, appelé aussi slick pour le temps sec, qui peut avoir différents degrés d’usure et un pneumatique avec des rainures, pour la pluie, qui est composé de plusieurs pneus en fonction du degré d’intensité de la pluie. La taille des penus augmente de quelques centimètres.";
  }  else if (x > 20 && x<323 && y > 220 && y < 243 ||x > 278 && x<421 && y > 19 && y < 36  ) {
    info.innerHTML = "L'Aérodynamique: En 2011, le DRS, ou en anglais le drag reduction system, est mis en place, car les dépassements sont très difficiles à cette période. Ce système situé sur l’aileron arrière permet de mettre à plat cet aileron pour réduire la traînée aérodynamique. La voiture possède ainsi moins de contraintes face à l’air, ce qui procure un net avantage au pilote qui l’actionne par un bouton situé sur le volant. Ce système ne peut être utilisé que dans les zones prévues à cet effet et seulement lorsque le pilote est suffisamment proche du pilote devant lui."; 
  } else if (x > 214 && x<282 && y > 77 && y < 123 ) {
    info.innerHTML = "Le Volant: Le volant possède désormais un écran de 10 cm. Après l’arrivée des moteurs hybrides en 2014, l’écran doit pouvoir afficher énormément de choses comme les niveaux d’énergies, la température des pneus, le temps au tour et la température des freins. Même si l’écran prend une place importante, il reste de la place pour des boutons. Certains servent à limiter la vitesse dans les stands, d’autres servent à mettre la boîte de vitesses en position neutre ou à activer le DRS pour dépasser. Le volant, composé de carbone, permet de modifier les réglages presque de manière illimitée.";
  }
   
  else if (x > 296 && x<378 && y > 49&& y < 155 ||x > 362 && x<394 && y > 107 && y < 204  ) {
    info.innerHTML = "Le Moteur: Les V8 de 2,4 litres assourdissants, imposés depuis 2006, sont remplacés en 2014 par des V6 de 1,5 litres hybrides possédant deux nouveaux systèmes de récupération d’énergie appelés “MGU-K” et “MGU-H”. La puissance peut monter jusqu'à 1000 chevaux. Ils possèdent, pour la première fois depuis 1989, des turbocompresseurs dont le régime de tours minutes est limité à 15000 tours minute. Les spectateurs sont déçus du bruit, car les anciens moteurs atmosphériques pouvaient monter jusqu’à 20000 tours minute.";
  }
  else if (x > 242 && x<294 && y > 129&& y < 182) {
    info.innerHTML = "La Sécurité: Après de nombreux accidents où des pilotes sont frappés à la tête par des projectiles, un nouveau dispositif de sécurité est mis en place en 2018. Le halo est une barre de titane de 7 kg fixée en trois points au niveau du cockpit. Elle peut supporter une charge de plus de 12 tonnes. D’après un rapport de la FIA, le halo a augmenté les chances de survie lors d’un accident de plus de 17%. Certains pilotes dubitatifs ont pu éviter le pire grâce à ce dispositif, qui semble être une des plus grandes avancées de ce sport.";
  }

})